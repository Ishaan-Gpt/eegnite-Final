"use client";

import { HeroSection } from "@/components/ui/hero-section";
import FloatingIconsHeroDemo from "@/components/FloatingIconsHeroDemo";

export default function Hero() {
    return <FloatingIconsHeroDemo />;
}
